#!/system/bin/sh
MODDIR=${0%/*}
while :
do
    date "+%Y-%m-%d %H:%M:%S"  >> ${MODDIR}/miuitask.log 2>&1
    until ping -c 1 114.114.114.114; do
      sleep 1
    done
    
    cd ${MODDIR}
    export TMPDIR=${MODDIR}
    
    ${MODDIR}/miuitask >> ${MODDIR}/miuitask.log 2>&1   

    sleep 86400
done
