#!/system/bin/sh

ui_print "- 开始设置环境权限."
set_perm_recursive ${MODPATH} 0 0 0755 0755
set_perm  ${MODPATH}/miuitask 0 0 0755
ui_print "严禁转发到公共社交平台、论坛!!!"
ui_print "严禁转发到公共社交平台、论坛!!!"
ui_print "严禁转发到公共社交平台、论坛!!!"
ui_print ""
ui_print "在小米社区提起此脚本/模块的你妈死了 你这辈子就是小米性奴 舔你那米爹"
ui_print "在小米社区提起此脚本/模块的你妈死了 你这辈子就是小米性奴 舔你那米爹"
ui_print ""
ui_print "************************************************"
ui_print "配置教程见 https://github.com/0-8-4/miui-auto-tasks"
ui_print "配置文件在${MODPATH}/data下"
ui_print ""
ui_print "！！！为了让你阅读以上消息，安装进度暂停5秒！！！"
ui_print "重启后生效"
sleep 5

cd ${MODPATH}
${MODPATH}/miuitask >> null

ui_print "安装完成"
